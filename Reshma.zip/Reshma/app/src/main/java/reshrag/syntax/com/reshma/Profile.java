package reshrag.syntax.com.reshma;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

import com.squareup.picasso.Picasso;

public class Profile extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);


        ImageView profileImageView = (ImageView) findViewById(R.id.profileImageView);
        TextView userNameTextView = (TextView) findViewById(R.id.usernameTextView);
        ImageButton shareProfile = (ImageButton) findViewById(R.id.shareProfile);
        TextView developerUrl = (TextView) findViewById(R.id.developerUrl);

        userNameTextView.setText(getIntent().getStringExtra(ListAdapter.KEY_NAME));
        developerUrl.setText(getIntent().getStringExtra(ListAdapter.KEY_URL));

        Picasso.with(this)
                .load(getIntent().getStringExtra(ListAdapter.KEY_URL))
                .into(profileImageView);

    }
}
