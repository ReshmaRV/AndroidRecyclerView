package reshrag.syntax.com.reshma;

import android.content.Context;
import android.content.Intent;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.squareup.picasso.Picasso;

import java.util.List;

/**
 * Created by user22 on 1/11/2019.
 */

public class ListAdapter extends RecyclerView.Adapter<ListAdapter.ViewHolder> {


    public static final String KEY_NAME = "name";
    public static final String KEY_IMAGE = "image";
    public static final String KEY_URL = "url";

    //this context we will use to inflate the layout
    private Context mCtx;

    //we are storing all the products in a list
    List<ListDev> listDev;

    //getting the context and product list with constructor

    public ListAdapter(List<ListDev> listDev, Context applicationContext) {
        this.mCtx = applicationContext;
        this.listDev = listDev;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        //inflating and returning our view holder


        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.activity_list, null);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, final int position) {

 final ListDev listDevs=listDev.get(position);
 holder.login.setText(listDevs.getLogin());

        Picasso.with(mCtx)
                .load(listDevs.getAvatar_url())
                .into(holder.avatar_url);

        holder.linearLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ListDev developersList1 = listDev.get(position);
                Intent skipIntent = new Intent(v.getContext(), Profile.class);
                skipIntent.putExtra(KEY_NAME, developersList1.getLogin());
                skipIntent.putExtra(KEY_URL, developersList1.getHtml_url());
                skipIntent.putExtra(KEY_IMAGE, developersList1.getAvatar_url());
                v.getContext().startActivity(skipIntent);
            }
        });


    }



    @Override
    public int getItemCount() {
        return listDev.size();
    }


    class ViewHolder extends RecyclerView.ViewHolder {

        public TextView login;
        public ImageView avatar_url;
        public TextView html_url;
        public LinearLayout linearLayout;

        public ViewHolder(View itemView) {
            super(itemView);

            login = itemView.findViewById(R.id.username);
            html_url = itemView.findViewById(R.id.htmUrl);
            linearLayout=itemView.findViewById(R.id.linearLayout);
            avatar_url = itemView.findViewById(R.id.imageView);
        }
    }
}
